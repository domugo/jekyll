# frozen_string_literal: true

module Jekyll
  VERSION = "3.6.0".freeze
end
