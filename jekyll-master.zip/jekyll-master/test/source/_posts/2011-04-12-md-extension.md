---
date: 2011-04-12 13:07:09
---

under default configuration, this post should get processed by the identity converter. By changing
textile extension or markdown extension configuration parameters, you should be able to associate
it with either of those converters